#leia uma quantidade n de números positivos. Calcule a quantidade de números pares e ímpares, a média de valores pares e a média geral dos números lidos. O número que encerrará a leitura será zero.
def calcular_pares_impares():
    total_numeros = 0
    soma_numeros = 0
    quantidade_pares = 0
    soma_pares = 0
    quantidade_impares = 0

    while True:
        numero = int(input("Digite um número positivo (ou 0 para terminar): "))
        if numero == 0:
            break
        if numero > 0:
            total_numeros += 1
            soma_numeros += numero

            if numero % 2 == 0:
                quantidade_pares += 1
                soma_pares += numero
            else:
                quantidade_impares += 1
        else:
            print("Por favor, insira apenas números positivos ou 0 para terminar.")

    if total_numeros > 0:
        media_pares = soma_pares / quantidade_pares if quantidade_pares > 0 else 0
        media_geral = soma_numeros / total_numeros

        print(f"Quantidade de números pares: {quantidade_pares}")
        print(f"Quantidade de números ímpares: {quantidade_impares}")
        print(f"Média dos valores pares: {media_pares:.2f}")
        print(f"Média geral dos números lidos: {media_geral:.2f}")
    else:
        print("Nenhum número positivo foi inserido.")

calcular_pares_impares()