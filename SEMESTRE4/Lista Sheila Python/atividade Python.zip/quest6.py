#gera e escreve os números ímpares entre 100 e 200. 
def escrever_impares():
    for numero in range(101, 200, 2):
        print(numero)

escrever_impares()