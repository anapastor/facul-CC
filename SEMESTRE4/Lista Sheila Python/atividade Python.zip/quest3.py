#leia um número n de valores e escreva a MÉDIA, a QUANTIDADE DE positivos e negativos, o PERCENTUAL de valores negativos e positivos.
def calcular_estatisticas():
    valores = []
    positivos = 0
    negativos = 0

    while True:
        entrada = input("Digite um número (ou 'sair' para terminar): ")
        if entrada.lower() == 'sair':
            break
        try:
            valor = float(entrada)
            valores.append(valor)
            if valor > 0:
                positivos += 1
            elif valor < 0:
                negativos += 1
        except ValueError:
            print("Por favor, digite um número válido ou 'sair'.")

    if valores:
        media = sum(valores) / len(valores)
        total_valores = len(valores)
        percentual_positivos = (positivos / total_valores) * 100
        percentual_negativos = (negativos / total_valores) * 100

        print(f"Média aritmética: {media}")
        print(f"Quantidade de valores positivos: {positivos}")
        print(f"Quantidade de valores negativos: {negativos}")
        print(f"Percentual de valores positivos: {percentual_positivos:.2f}%")
        print(f"Percentual de valores negativos: {percentual_negativos:.2f}%")
    else:
        print("Nenhum valor foi inserido.")

calcular_estatisticas()